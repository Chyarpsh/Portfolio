# Cloud Portfolio (Purple + Green)

Simple, professional one-page portfolio for Cloud Support / Junior Cloud Engineer roles.

## Replace your repo files with:
- `index.html`  → use `UPDATED_index.html` (rename to `index.html`)
- `styles.css`  → use `UPDATED_styles.css` (rename to `styles.css`)
- `script.js`   → use `UPDATED_script.js` (rename to `script.js`)
- `README.md`   → use `UPDATED_README.md` (rename to `README.md`)

## Resume link
Make sure the resume filename in your repo is exactly:
`Arpita_Chowdhury_Resume.pdf`

## Deploy (GitHub Pages)
Repo → Settings → Pages → main branch → /root
